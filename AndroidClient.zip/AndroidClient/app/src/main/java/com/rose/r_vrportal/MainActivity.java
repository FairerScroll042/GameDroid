package com.rose.r_vrportal;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import org.webrtc.*;

public class MainActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
    }
}
